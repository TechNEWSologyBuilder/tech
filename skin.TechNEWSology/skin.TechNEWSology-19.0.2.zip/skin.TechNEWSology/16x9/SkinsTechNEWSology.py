import os, xbmc, xbmcgui

DIALOG         = xbmcgui.Dialog()

choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology Skins[/COLOR]', '[COLOR orange]Επιλέξτε το κατάλληλο κέλυφος ανάλογα με τις δυνατότητες της συσκευής σας. Για καλύτερα αποτελέσματα όσο αναφορά την ταχύτητα της συσκευής, απενεργοποιήστε τα widgets από τα εργαλεία που βρίσκονται επάνω με σύμβολο το πινέλο.        Σε συσκευές χαμηλής απόδοσης προτείνεται το κέλυφος [B][COLOR white]TechNEWSology Faster[/COLOR][/B].',
                                nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Εγκατάσταση Κελύφους[/COLOR]')
if  choice == 1: xbmc.executebuiltin('ActivateWindow(10040,"addons://repository.TechNEWSology.Gkn/category.lookandfeel",return)')

