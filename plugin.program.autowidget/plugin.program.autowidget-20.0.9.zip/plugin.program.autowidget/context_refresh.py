from resources.lib import refresh


if __name__ == '__main__':
    refresh.refresh_paths(notify=True, force=True)
