import xbmc, xbmcgui, webbrowser
android = xbmc.getCondVisibility('system.platform.android')

def SitesMenu():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2, site3, site4, site5, site6, site7, site8)
    xbmcgui.Dialog().ok("[B][COLOR orange]TechNEWSology[/COLOR][/B]", "[B][COLOR white]Κατεβάζουμε τους υπότιτλους που επιθυμούμε σε ένα φάκελο και στη συνέχεια τους εισάγουμε από την επιλογή - LocalSubtitle -> [COLOR orange]Browse...[/COLOR][/B]")
    call = dialog.select('[B][COLOR=orange]Αναζήτηση υπότιτλων σε ιστότοπους...[/COLOR][/B]', 
['[B][COLOR=white]Subs4Free[/COLOR][/B]', '[B][COLOR=white]Subs4Series[/COLOR][/B]','[B][COLOR=white]Greeksubs[/COLOR][/B]', '[B][COLOR=white]Opensubtitles[/COLOR][/B]', '[B][COLOR=white]TVsubtitles[/COLOR][/B]', '[B][COLOR=white]Podnapisi[/COLOR][/B]', '[B][COLOR=white]Yifysubtitles[/COLOR][/B]', '[B][COLOR=white]Subscene[/COLOR][/B]'])

    if call:
        if call < 0:
            return 
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def site1():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.subs4free.info/' ) )
    else: opensite = webbrowser . open('https://www.subs4free.info/')

def site2():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.subs4series.com/' ) )
    else: opensite = webbrowser . open('https://www.subs4series.com/')

def site3():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://greeksubs.net/' ) )
    else: opensite = webbrowser . open('https://greeksubs.net/')

def site4():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.opensubtitles.org/el' ) )
    else: opensite = webbrowser . open('https://www.opensubtitles.org/el')

def site5():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.tvsubtitles.net/' ) )
    else: opensite = webbrowser . open('http://www.tvsubtitles.net/')


def site6():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.podnapisi.net/' ) )
    else: opensite = webbrowser . open('https://www.podnapisi.net/')

def site7():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://yifysubtitles.live/' ) )
    else: opensite = webbrowser . open('https://yifysubtitles.live/')


def site8():
    if android: opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://subscene.com/' ) )
    else: opensite = webbrowser . open('https://subscene.com/')

SitesMenu()
