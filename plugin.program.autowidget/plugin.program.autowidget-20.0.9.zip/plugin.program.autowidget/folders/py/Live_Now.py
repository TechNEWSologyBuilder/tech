import xbmc, xbmcgui


def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15, click_16, click_17, click_18)
    call = xbmcgui.Dialog().select('[B][COLOR=lime]                                               Live Now...[/COLOR][/B]', 
['[B][COLOR=blue]                                                GR [COLOR=white]Sport Channels[/COLOR][/B]',
 '[B][COLOR=white]                                            Live [COLOR=lime]Soccer [COLOR=orange](SportsHD)[/COLOR][/B]',
 '[B][COLOR=white]                                            Live Events [COLOR=orange](SportsHD)[/COLOR][/B]',
 '[B][COLOR=white]                                Alternative Live Events [COLOR=orange](SportsHD)[/COLOR][/B]',
 '[B][COLOR=white]                                         DaddyliveHD [COLOR=lime]Soccer[COLOR=orange] (Atlas)[/COLOR][/B]',
 '[B][COLOR=white]                                            DaddyliveHD Live[COLOR=orange] (Atlas)[/COLOR][/B]',
 '[B][COLOR=white]                                                      Rising Tides[/COLOR][/B]',
 '[B][COLOR=white]                                           Livetv.sx [COLOR=orange](Apex Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                                         vStream[/COLOR][/B]',
 '[B][COLOR=white]                                                        The Loop[/COLOR][/B]',
 '[B][COLOR=lime]                                           Αναζήτηση... [COLOR=orange](The Loop)[/COLOR][/B]',
 '[B][COLOR=white]                                                Live [COLOR=orange](Mad Titan Sports)[/COLOR][/B]',
 '[B][COLOR=lime]                                      Αναζήτηση... [COLOR=orange](Mad Titan Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                                Daddylive Live Sports[/COLOR][/B]',
 '[B][COLOR=white]                                                          Sport LIVE[/COLOR][/B]',
 '[B][COLOR=white]                                                             Winner[/COLOR][/B]',
 '[B][COLOR=white]                                           Live Sports [COLOR=orange](Cendry Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                                               Tide[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-18]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/GreekChannels.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sporthdme/?description=Football&iconimage=https%3a%2f%2fmy.livesoccer.sx%2fimages%2ffootball.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dFootball%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fmy.livesoccer.sx%2f%3ftype%3dfootball,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sporthdme/?description&mode=5,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sporthdme/?description&mode=15&name=%5bB%5d%5bCOLOR%20white%5dNEW%20VIEW%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.vecdn.pw%2fprogram.php,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?mode=trList&trType=Soccer",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?mode=menu&serv_type=sched",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Rising.Tides",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.apex_sports/?category=live_sport&mode=open_site&site=livetv",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showSports&sFav=showSports&site=cHome&title=Sports",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/ls3arch1/search/*",return)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/get_list/https://magnetic1.ratpack.appboxes.co/MAD_TITAN_SPORTS/SPORTS/sports.json",return)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/pvr_sport_search/search/*?include=6",return)')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportliveevents/",return)')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.winner",return)')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.centrysports/category/Sports",return)')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tide,return)')


live_now()
