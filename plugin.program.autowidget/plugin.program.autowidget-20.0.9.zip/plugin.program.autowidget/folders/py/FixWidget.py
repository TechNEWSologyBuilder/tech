import xbmc, xbmcgui

def fix_widgets():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]            Στο επόμενο βήμα πατάμε καθαρισμός όλων[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Συνέχεια[/COLOR]')

        if choice == 1:
                       xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=fullclean)')
                       xbmc.sleep(12000)
                       xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=convertpath)')
                       xbmc.sleep(5000)
                       xbmc.executebuiltin("ReloadSkin")

fix_widgets()
