import os, xbmcvfs, xbmcgui, shutil, glob
translatePath   = xbmcvfs.translatePath

base_path = translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "plugin.program.indigo"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

base_path = translatePath('special://home/userdata/addon_data')

dir_list = glob.iglob(os.path.join(base_path, "plugin.program.indigo"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

base_path = translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "script.tvaddons.debug.log"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dialog = xbmcgui.Dialog()
dialog.ok("[COLOR orange]TechNEWSology Skins[/COLOR]", "[COLOR white]Bye Bye --> plugin.program.indigo[/COLOR]")