import xbmc,xbmcgui

def ClearingPvrData():
    xbmc.executebuiltin("ActivateWindowAndFocus(pvrsettings, 100,0 , -69,0)")
    xbmc.executebuiltin('SendClick(-69)')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin("ActivateWindow(10700)")
    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]", "[COLOR white]Περιμένουμε να ολοκληρωθεί η εισαγωγή οδηγού από πελάτες της διαχείρισης PVR. Μην ξεχάσετε να κάνετε αλλαγή Γκρουπ στην χώρα ή στην κατηγορία που επιθυμείτε.[/COLOR]", icon='special://skin/icon.png')

ClearingPvrData()

