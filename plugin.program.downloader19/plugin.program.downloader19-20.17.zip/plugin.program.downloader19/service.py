﻿# -*- coding: utf-8 -*-
import xbmc
from updatervar import *
from resources.lib.modules import check
from resources.lib.GUIcontrol.txt_updater import get_check
check_version = get_check()

if __name__ == '__main__':
    if not setting('updaterversion') == 'false':
        dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
        if check_version > int(setting('checkversion')):
    #        check.Update()
            check.autoenable()
            check.check()
            check.var()
            check.players()
            check.delete()
            check.zip1()
            check.zip2()
            check.zip3()
            check.zip4()
            check.zip5()
            check.installation()
            check.updater()
            check.setsetting()
            check.database()
            check.xmlskin()
            check.UpdateAddonRepos()
            check.notifyT()
        else:
            check.Update()
            check.autoenable()
            check.notifyT()

    else:
        dialog.notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
        check.autoenable()
        check.notifyT()
        check.Update()

