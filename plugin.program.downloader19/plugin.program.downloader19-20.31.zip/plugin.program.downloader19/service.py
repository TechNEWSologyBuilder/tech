﻿""""""""""""""""""""""""""""""""""""""""""
"""  Believe in God - Ηelp as you can  """
""""""""""""""""""""""""""""""""""""""""""
import xbmc
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":2}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')

from updatervar import *
from resources.lib.modules import check
from resources.lib.GUIcontrol.txt_updater import get_check
check_version = get_check()


if __name__ == '__main__':
    if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology')):
        if not setting('updaterversion') == 'false':
            xbmcgui.Dialog().notification('[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]', '[B][COLOR white]Έναρξη TechNEWSology Updater ...[/COLOR][/B]', 'special://skin/icon.png', sound=False)
            if check_version > int(setting('checkversion')):
                check.addonupdates_Disable()
                check.autoenable()
                check.var()
                check.players()
                check.skin_py()
                check.delete()
                check.zip1()
                check.zip2()
                check.zip3()
                check.zip4()
                check.zip5()
                check.zip6()
                check.zip7()
                check.zip8()
                check.zip9()
                check.zip10()
                check.zip11()
                check.zip12()
                check.installation()
                check.updater()
                check.setsetting()
                check.database()
                check.xmlskin()
                check.UpdateAddonRepos()
                setting_set('checkversion', str(check_version))
                check.notifyT()
            else:
                check.autoenable()
                check.Update()
                check.notifyT()

        else:
            xbmcgui.Dialog().notification('[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]', '[B]Οι αυτόματες ενημερώσεις είναι απενερ/μένες[/B]', 'special://skin/icon.png', sound=False)
            check.autoenable()
            check.Update()
            check.notifyT()

