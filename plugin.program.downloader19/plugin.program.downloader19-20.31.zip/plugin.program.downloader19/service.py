﻿""""""""""""""""""""""""""""""""""""""""""
"""  Believe in God - Ηelp as you can  """
""""""""""""""""""""""""""""""""""""""""""
from updatervar import *
from resources.lib.modules import check
from resources.lib.GUIcontrol.txt_updater import get_check
check_version = get_check()


if __name__ == '__main__':
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
    if not setting('updaterversion') == 'false':
        xbmcgui.Dialog().notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
        if check_version > int(setting('checkversion')):
            check.addonupdates_Disable()
            check.autoenable()
            check.var()
            check.players()
            check.skin_py()
            check.delete()
            check.zip1()
            check.zip2()
            check.zip3()
            check.zip4()
            check.zip5()
            check.zip6()
            check.zip7()
            check.zip8()
            check.zip9()
            check.zip10()
            check.zip11()
            check.zip12()
            check.installation()
            check.updater()
            check.setsetting()
            check.database()
            check.xmlskin()
            check.UpdateAddonRepos()
            setting_set('checkversion', str(check_version))
            check.notifyT()
        else:
            check.autoenable()
            check.Update()
            check.notifyT()

    else:
        xbmcgui.Dialog().notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
        check.autoenable()
        check.Update()
        check.notifyT()

