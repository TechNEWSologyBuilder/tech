﻿import xbmc, xbmcgui



def t_menu():
    funcs = (click1, click2, click3, click4, click5, click6, click7, click8, click9, click10, click11, click12, click13, click14, click15,
             click16, click17, click18, click19, click20, click21, click22, click23, click24, click25, click26, click27, click28, click29, click30)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                                                    ~ Εργαλεία ~[/COLOR][/B]',
['[B][COLOR=white]             Επαναφορά Ενημέρωσης Μενού [COLOR=orange](Skinshortcuts-Xml Skin)[/COLOR][/B]',
 '[B][COLOR=lime]                           Ενεργοποίηση [COLOR=white]όλων των πρόσθετων ...[/COLOR][/B]',
 '[B][COLOR=white]                               Έλεγχος Αναβάθμισης Πρόσθετων ...[/COLOR][/B]',
 '[B][COLOR=white]                   Αν δεν εμφανίζονται τα Widgets ή τα Εικονίδια ...[/COLOR][/B]',
 '[B][COLOR=white]                                     DNS Leak Test [COLOR=dodgerblue]G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                                 Advanced Settings [COLOR=dodgerblue]G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                   Advanced Settings [COLOR=orange]TechNEWSology Updater - Tools[/COLOR][/B]',
 '[B][COLOR=white]                                            Ρυθμίσεις [COLOR lime]ResolveURL[/COLOR][/B]',
 '[B][COLOR=white]                                         Επιλογή Api Key [COLOR red]YouTube[/COLOR][/B]',
# '[B][COLOR=white]                                   Έληξε η Συνδρομή μας [COLOR lime]AllDebrid ...[/COLOR][/B]',
# '[B][COLOR=white]                             Έληξε η Συνδρομή μας [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                            Εξουσιοδότηση [COLOR lime]Trakt ...[/COLOR][/B]',
 '[B][COLOR=white]                                    Αντίγραφο ασφαλείας Build[/COLOR][/B]',
 '[B][COLOR=lime]                          Καθαρή Εγκατάσταση Build [B][COLOR orange]*ΧΩΡΙΣ ΚΩΔΙΚΟ*[/COLOR][/B]',
 '[B][COLOR=white]                        Επαναφορά απο αντίγραφο ασφαλείας Build[/COLOR][/B]',
 '[B][COLOR=orange]                                 TechNEWSology Updater - Tools[/COLOR][/B]',
 '[B][COLOR=white]                          Έγκριση του λογαριασμού μου [COLOR lime]RealDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                            Έγκριση του λογαριασμού μου [COLOR lime]AllDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                       Έγκριση του λογαριασμού μου [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                      Εγκατάσταση Binary Addons[/COLOR][/B]',
 '[B][COLOR=red]                                            Διαγραφή[COLOR=white] PVR Stalker[/COLOR][/B]',
 '[B][COLOR=white]                                         Εργαλεία G.K.N.Wizard[/COLOR][/B]',
# '[B][COLOR=white]                                              Διαγραφή Indigo...[/COLOR][/B]',
 '[B][COLOR=white]                                                  G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                                          Αφαίρεση πρόσθετων[/COLOR][/B]',
 '[B][COLOR=lime]                                    Καθαρισμός[COLOR=white] παρόχων-Cache[/COLOR][/B]',
 '[B][COLOR=white]                                                    Save Data[/COLOR][/B]',
 '[B][COLOR=white]                                                   Reload Skin[/COLOR][/B]',
 '[B][COLOR=white]                                         Enable/Disable Addons[/COLOR][/B]',
 '[B][COLOR=white]                                                    Speed Test[/COLOR][/B]',
 '[B][COLOR=white]                                              Εργαλεία AliveGR[/COLOR][/B]',
 '[B][COLOR=orange]   Απενεργοποίηση [COLOR=white]αυτόματων ενημερώσεων του Downloader Startup[/COLOR][/B]',
 '[B][COLOR=lime]     Ενεργοποίηση [COLOR=white]αυτόματων ενημερώσεων του Downloader Startup[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-30]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2FBackgrounds_With_Widgets.zip&mode=9)')
    xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[B][COLOR white]Αναμονή... προς ολοκλήρωση διαδικασίας![/COLOR][/B]', '', sound=False)
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2FXmlSkin_startup.zip&mode=9)')
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")

def click2():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=25,return)')

def click3():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=kodi17fix)')

def click4():
    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/FixWidget.py)')

def click5():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=dnsleaktest,return)')

def click6():
    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/AdvancedSettings.py)')

def click7():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=4,return)')

def click8():
    import resolveurl
    resolveurl.display_settings()

def click9():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=1,return)')

#def click7():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/ResolverOffAllDebrid.py)')

#def click8():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/ResolverOffPremiumizeMe.py)')

def click10():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.scrubsv2/?action=auth_trakt)')

def click11():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=18,return)')

def click12():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FBuilds%2FTechNEWSology_19_20_21.zip&mode=11&name=TechNEWSolgy+Build)')

def click13():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=19,return)')

def click14():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19,return)')

def click15():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

def click16():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')

def click17():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')

def click18():
    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/installer_binary.py)')

def click19():
    xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/StalkerDelete.py")')

#def click15():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/indigoDel.py)')

def click20():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=maint,return)')

def click21():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard)')

def click22():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=removeaddons,return)')

def click23():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=clearcache)')
    xbmc.sleep(2500)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.sleep(600)
        xbmc.executebuiltin('SendClick(11)')
        xbmc.sleep(1500)
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=23)')
        xbmc.sleep(8000)
        xbmc.executebuiltin('SendClick(11)')

def click24():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=savedata,return)')

def click25():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceskin)')

def click26():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=enableaddons,return)')

def click27():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?url=&mode=31,return)')

def click28():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=settings,return)')

def click29():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=29,return)')

def click30():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=30,return)')


t_menu()
