﻿import os, xbmc, xbmcgui

DIALOG         = xbmcgui.Dialog()
choice = 1
choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology Skins[/COLOR]', '[COLOR white]Με αυτή την επιλογή θα απενεργοποιηθούν τα widgets όλων των κατηγοριών. Αυτό θα έχει ως αποτέλεσμα μείωση κατανάλωσης της μνήμης στη συσκευή σας με όφελος γρηγορότερη εναλλαγή κατηγοριών και έναρξης του Build.', '[COLOR lime]Η διαφορά στην ταχύτητα θα είναι αισθητή !!![/COLOR]',
                                nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR orange]Απεν/ση Widgets[/COLOR]')
if  choice == 1: xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/folders/PY/SkinshortcutsDel.py)')
xbmc.executebuiltin("Action(Close)")
