import xbmc, xbmcgui


def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                               Live Now...[/COLOR][/B]', 
['',
 '[B][COLOR=white]                                           Live Events [COLOR=orange](SportHD)[/COLOR][/B]',
 '[B][COLOR=white]                                    Rojadirecta.me [COLOR=orange](Apex Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                         Livetv.sx [COLOR=orange](Apex Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                        Live Sport [COLOR=orange](Apex Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                                  Sportowa TV[/COLOR][/B]',
 '[B][COLOR=white]                                           LiveTV.sx [COLOR=orange](Sportowa)[/COLOR][/B]',
 '[B][COLOR=white]                                           SportsBay [COLOR=orange](Sportowa)[/COLOR][/B]',
 '[B][COLOR=white]                                                       Cloud9[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin("Action(Close)")

#def click_2():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sporthdme/?mode=5,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=open_site&amp;site=rojadirecta,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=open_site&amp;site=livetv,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=open_category,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.PLsportowo)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.PLsportowo/?mode=livetvsx&amp;title=LiveTV.sx&amp;url=http%3a%2f%2flivetv.sx%2fenx%2fallupcoming%2f,return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.PLsportowo/?mode=getsportsbay&amp;title=SportsBay&amp;url=http%3a%2f%2fstrims.world,return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.Cloud9)')


live_now()
