import os, xbmc, xbmcvfs, xbmcgui, shutil, glob, time
DIALOG         = xbmcgui.Dialog()


base_path = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
dir_list = glob.iglob(os.path.join(base_path, "skinshortcuts.zip*"))
for path in dir_list:
     if os.path.isfile(path):
        os.remove(path)
time.sleep(1)
xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader/service?sf_options=meta%3Dlabel%253DDownload%252BTest%26,return)')
time.sleep(5)
dialog = xbmcgui.Dialog()
dialog.ok("[COLOR orange]TechNEWSology Skins[/COLOR]", "[B][COLOR white]Welcome back Widgets !!![/COLOR][/B]", "", "[COLOR white]Wait a minute ...[/COLOR]")
