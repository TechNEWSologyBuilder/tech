import os, xbmc, xbmcvfs, xbmcgui, shutil, glob


base_path = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
dir_list = glob.iglob(os.path.join(base_path, "skin.TechNEWSology*"))
for path in dir_list:
     if os.path.isfile(path):
        os.remove(path)

base_path = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
dir_list = glob.iglob(os.path.join(base_path, "skin.TechNEWSology.hash*"))
for path in dir_list:
     if os.path.isfile(path):
        os.remove(path)


dialog = xbmcgui.Dialog()
dialog.ok('[COLOR orange]TechNEWSology Skins[/COLOR]', '[B][COLOR white]Bye Bye Widgets !!![/COLOR][/B]')