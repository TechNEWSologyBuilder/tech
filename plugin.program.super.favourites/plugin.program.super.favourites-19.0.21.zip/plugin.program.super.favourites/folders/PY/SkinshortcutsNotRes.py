﻿import os, xbmc, xbmcgui

DIALOG         = xbmcgui.Dialog()
choice = 1
choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology Skins[/COLOR]', '[COLOR white]Με αυτή την επιλογή επαναφέρονται τα widgets όλων των κατηγοριών στην αρχική επιλογή του Build.[/COLOR]',
                                nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR orange]Επαναφορά Widgets[/COLOR]')
if  choice == 1: xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/folders/PY/SkinshortcutsRes.py)')
xbmc.executebuiltin("Action(Close)")
