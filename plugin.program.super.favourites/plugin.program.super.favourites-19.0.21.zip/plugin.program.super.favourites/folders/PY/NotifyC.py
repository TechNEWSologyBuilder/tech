﻿import xbmcgui

xbmcgui.Dialog().ok("[COLOR orange]info[/COLOR]", "[COLOR white] - Εάν μια συντόμευση κατηγορίας δεν ανοίξει με το πρώτο πάτημα, προσπαθήστε ξανά.", " Εάν πάλι όχι, τότε βγείτε έξω και δοκιμάστε την αντίστοιχη συντόμευση στο Submenu.[/COLOR]")


