# -*- coding: utf-8 -*-
"""
    **Created by Tempest** -->  Repair TK
"""

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['r1.dldrm.ir']
        self.base_link = 'http://r1.dldrm.ir/'
        self.search_link = 'Movie/%s/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.get_query(title)
            self.title = '%s.%s' % (title, year)
            self.year = year
            url = self.base_link + self.search_link % self.year
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if debrid.status() == True: raise Exception()
            r = requests.get(result, timeout=15).content
            r = re.findall('A HREF=".+?">(.+?)<', r)
            for u in r:
                if not self.title in u: continue
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3']): continue
                url = self.base_link + self.search_link % self.year + u
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return

    def resolve(self, url):
        return url
