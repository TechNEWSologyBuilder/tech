# -*- coding: utf-8 -*-

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['golchindl.net']
        self.base_link = 'https://golchindl.net/'
        self.search_link = 'search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.get_query(title)
            self.title = '%s %s' % (title, year)
            self.year = year
            url = self.base_link + self.search_link % self.title
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if debrid.status() == True: raise Exception()
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.findall('a style="color: #003366;" href="(.+?)"', r)
            for u in r:
                if any(x in u for x in ['Trailer', '.rar', '.zip', '.jpg', '.mp3']): continue
                url = u
                info = url.split('/')[-1]
                quality = source_utils.check_url(info)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return sources

    def resolve(self, url):
        return url
