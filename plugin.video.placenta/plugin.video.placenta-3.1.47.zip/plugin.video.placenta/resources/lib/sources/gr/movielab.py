# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re, json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['movielab.online']
        self.base_link = 'https://movielab.online/'
        self.search_link = 'secure/search/{}?type=&limit=20&provider='
        self.get_links_url = 'secure/titles/{0}?titleId={0}'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'localtitle': localtitle, 'title': title, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            sources = []

            if url == None:
                return sources
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = 's%02de%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '{}'.format(data['tvshowtitle']) if 'tvshowtitle' in data else '{}'.format(data['title'])#data['year'])
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link.format(urllib.quote(query))
            url = urlparse.urljoin(self.base_link, url)
            r = client.request(url)
            r = json.loads(r)
            posts = r['results']
            for post in posts:
                try:
                    name = post['name']
                    # print name
                    name = client.replaceHTMLCodes(name)

                    t = re.sub(r'(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, re.I)
                    if not cleantitle.get(t) == cleantitle.get(title):
                        raise Exception()

                    y = post['year']
                    year = data['year']
                    if not str(y) == str(year):
                        raise Exception()
                    t_id = post['id']
                    if not 'tvshowtitle' in data:
                        frame = ''.join([self.base_link, self.get_links_url.format(t_id)])
                        r = json.loads(client.request(frame))
                        links = r['title']['videos']
                    else:
                        sepis = '&seasonNumber={}&episodeNumber={}'.format(int(data['season']), int(data['episode']))
                        frame = ''.join([self.base_link, self.get_links_url.format(t_id), sepis])
                        r = json.loads(client.request(frame))
                        links = r['title']['videos']

                    for i in links:
                        url = i['url']
                        host = i['name']
                        if any(x in url for x in ['.online', 'filmer', '.bp', '.blogger']):
                            continue

                        url = client.replaceHTMLCodes(url)
                        url = url.encode('utf-8')
                        valid, host = source_utils.is_host_valid(url, hostDict)

                        if not valid:
                            continue

                        quality = 'SD'
                        info = 'SUB'

                        sources.append({'source': host, 'quality': quality, 'language': 'gr', 'url': url, 'info': info,
                                        'direct': False, 'debridonly': False})

                except:
                    pass

            return sources
        except:
            return sources

    def resolve(self, url):
        return url
