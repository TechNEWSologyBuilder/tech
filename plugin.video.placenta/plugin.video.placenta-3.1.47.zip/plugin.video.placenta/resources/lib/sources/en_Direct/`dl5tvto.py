# -*- coding: utf-8 -*-

"""
    **Created by Tempest** -->  Repair TK
"""

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['dl5.tvto.ga']
        self.base_link = 'http://dl5.tvto.ga/Series/'
        self.search_link = '%s/'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        if debrid.status() == True: raise Exception()
        try:
            title = cleantitle.get_query(tvshowtitle)
            title = '%s' % title.replace('.', '%20')
            url = self.base_link + self.search_link % title
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        if debrid.status() == True: raise Exception()
        try:
            self.se = 'S%02dE%02d' % (int(season), int(episode))
            season = 'S%02d/' % int(season)
            if not url: return
            url = url + season
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            se = self.se
            result = url
            r = requests.get(result, timeout=20).content
            r = re.compile('a href="(.+?)"').findall(r)
            for r in r:
                if not se in r: continue
                if any(x in r for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3']): continue
                if not any (x in r for x in ['.mp4', '.mkv']): continue
                url = result + r
                info = url.split('/')[-1]
                quality = source_utils.check_direct_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return

    def resolve(self, url):
        return url