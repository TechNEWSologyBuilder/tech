# -*- coding: utf-8 -*-
"""
    **Created by Tempest** -->  Repair TK
"""

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['wb586pz5u433u34vjm44.server-download.space']
        self.base_link = 'http://wb586pz5u433u34vjm44.server-download.space/backup/Movie/'

    def movie(self, imdb, title, localtitle, aliases, year):
        if debrid.status() == True: raise Exception()
        try:
            title = cleantitle.get_query(title)
            self.title = '%s.%s' % (title, year)
            return
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            try:
                contents = ['2019.12/', '2020.03/', '2020.04/', '2020.05/', '2020.06/', '2020.09/', '2020.10/', '2020.11/', '2020.1/', '2020.2/']
                for object in contents:
                    result = self.base_link + object
                    r = requests.get(result, timeout=15).content
                    r = re.compile('a href="(.+?)"').findall(r)
                    for url in r:
                        if not self.title in url: continue
                        if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3']): continue
                        url = result + url
                        info = url.split('/')[-1]
                        quality = source_utils.check_direct_url(url)
                        sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            except:
                return
            return sources
        except:
            return sources

    def resolve(self, url):
        return url
