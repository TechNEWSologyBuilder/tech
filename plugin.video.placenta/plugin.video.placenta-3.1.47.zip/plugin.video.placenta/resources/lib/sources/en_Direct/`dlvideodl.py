# -*- coding: utf-8 -*-
"""
    **Created by Tempest** -->  Repair TK
"""

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['dl2.videodl.pw']
        self.base_link = 'http://dl.videodl.pw/movies/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.get_query(title)
            self.title = '%s.%s' % (title, year)
            return
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if debrid.status() == True: raise Exception()
            try:
                url = self.base_link
                r = requests.get(url, timeout=15).content
                r = re.compile('a href="(.+?)"').findall(r)
                for url in r:
                    if not self.title in url: continue
                    if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3']): continue
                    url = self.base_link + url
                    info = url.split('/')[-1]
                    quality = source_utils.check_url(info)
                    sources.append({'source': 'DL', 'quality': '720p', 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            except:
                return
            return sources
        except:
            return sources

    def resolve(self, url):
        return url
