# -*- coding: utf-8 -*-
"""
    **Created by Tempest** -->  Repair TK
"""

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['']
        self.base_link = 'http://124.6.236.254:8080/movies/hollywood/2020/%s/'
        self.base_link1 = 'http://124.6.236.254:8080/movies/hollywood/2019/%s/'
        self.base_link2 = 'http://124.6.236.254:8080/movies/hollywood/2018/%s/'
        self.base_link3 = 'http://124.6.236.254:8080/movies/hollywood/2017/%s/'
        self.base_link4 = 'http://124.6.236.254:8080/movies/hollywood/2016/%s/'
        self.base_link5 = 'http://124.6.236.254:8080/movies/hollywood/2015/%s/'

    def movie(self, imdb, title, localtitle, aliases, year):
        if debrid.status() == True: raise Exception()
        try:
            title = cleantitle.get_query(title)
            title = '%s' % title.replace('.', '%20')
            self.title = '%s (%s)' % (title, year)
            self.year = year
            return
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            url = self.base_link % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href="(.+?)">.+?</a>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3', '.srt']): continue
                url = self.base_link % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})

            url = self.base_link1 % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href="(.+?)">.+?</a>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3', '.srt']): continue
                url = self.base_link1 % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})

            url = self.base_link2 % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href="(.+?)">.+?</a>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3', '.srt']): continue
                url = self.base_link2 % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})

            url = self.base_link3 % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href="(.+?)">.+?</a>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3', '.srt']): continue
                url = self.base_link3 % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})

            url = self.base_link4 % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href="(.+?)">.+?</a>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3', '.srt']): continue
                url = self.base_link4 % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})

            url = self.base_link5 % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href="(.+?)">.+?</a>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3', '.srt']): continue
                url = self.base_link5 % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'DL', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return

    def resolve(self, url):
        return url
