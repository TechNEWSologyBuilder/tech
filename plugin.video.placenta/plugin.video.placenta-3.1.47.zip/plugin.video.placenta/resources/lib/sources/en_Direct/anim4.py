# -*- coding: utf-8 -*-
"""
    **Created by Tempest** -->  Repair TK
"""

import re, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils, debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['bh4.animeserver.pw']
        self.base_link = 'http://bh4.animeserver.pw/Movie/2020/%s/'

    def movie(self, imdb, title, localtitle, aliases, year):
        if debrid.status() == True: raise Exception()
        try:
            title = cleantitle.get_query(title)
            self.title = '%s' % title.replace('.', '%20')
            self.year = year
            return
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            url = self.base_link % self.title
            if url is None: return
            r = requests.get(url, timeout=20).content
            r = re.compile('<a href=".+?" title="(.+?)">.+?</a></td>').findall(r)
            for url in r:
                if any(x in url for x in ['Trailer', 'Dubbed', '.rar', '.zip', '.jpg', '.mp3']): continue
                if not any (x in url for x in ['.mp4', '.mkv']): continue
                url = self.base_link % self.title + url
                info = url.split('/')[-1]
                quality = source_utils.check_url(url)
                sources.append({'source': 'Slow Source', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': True, 'debridonly': False})
            return sources
        except:
            return

    def resolve(self, url):
        return url
