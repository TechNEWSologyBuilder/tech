﻿import os, xbmc, xbmcvfs, xbmcgui


def widgetsDel():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology Skins[/COLOR]', '[COLOR white]Με αυτή την επιλογή θα αφαιρεθούν τα widgets όλων των κατηγοριών. Αυτό θα έχει ως αποτέλεσμα μείωση κατανάλωσης της μνήμης στη συσκευή σας με όφελος γρηγορότερη εναλλαγή κατηγοριών και έναρξης του Build.', '', '[COLOR lime]Η διαφορά στην ταχύτητα θα είναι αισθητή !!![/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Αφαίρεση Widgets[/COLOR]')

        if choice == 1: xbmcvfs.delete('special://skin/16x9/Includes_Widgets.xml'), xbmc.executebuiltin("Action(Close)"), xbmc.executebuiltin("ReloadSkin")
        if choice == 1: xbmcgui.Dialog().ok("[COLOR orange]TechNEWSology Skins[/COLOR]", "[B][COLOR lime]                          Αφαιρέθηκαν τα Widgets !![/COLOR][/B]", "", "                   [COLOR white]Αν επιθυμείτε την επαναφορά τους...                              .                         θα μεταβείτε στα Εργαλεία.[/COLOR]")


widgetsDel()
