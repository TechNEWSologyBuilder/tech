import os, xbmc, xbmcvfs, xbmcgui, shutil, glob, time
DIALOG         = xbmcgui.Dialog()


base_path = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.youtube')
dir_list = glob.iglob(os.path.join(base_path, "apikey2.zip*"))
for path in dir_list:
     if os.path.isfile(path):
        os.remove(path)
time.sleep(1)
xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader/service)')
time.sleep(5)
dialog = xbmcgui.Dialog()
dialog.ok("[COLOR orange]TechNEWSology[/COLOR]", "                                 [B][COLOR white]Api Key [COLOR red]You[COLOR white]Toube [COLOR red]2[/COLOR][/B]", "", "                                             [COLOR white]Ready ![/COLOR]")