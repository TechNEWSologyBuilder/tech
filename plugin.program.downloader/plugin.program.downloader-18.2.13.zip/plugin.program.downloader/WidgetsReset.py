﻿import os, xbmc, xbmcvfs, xbmcgui


def widgetsReset():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology Skins[/COLOR]', '[COLOR white]Με αυτή την επιλογή επαναφέρονται τα widgets όλων των κατηγοριών στην αρχική επιλογή του Build.[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Επαναφορά Widgets[/COLOR]')

        if choice == 1: xbmcvfs.delete('special://skin/16x9/Includes_Widgets.zip.md5'), xbmc.executebuiltin("Action(Close)"), xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader/service?sf_options=meta%3Dlabel%253DDownload%252BTest%26,return)')
        if choice == 1: xbmcgui.Dialog().ok("[COLOR orange]TechNEWSology Skins[/COLOR]", "[B][COLOR lime]                   Θα πραγματοποιηθεί επαναφορά [/COLOR][/B]", "", "                               [COLOR white]σε λίγα δευτερόλεπτα...[/COLOR]")


widgetsReset()
