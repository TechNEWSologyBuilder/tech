import os, xbmc, xbmcvfs, xbmcgui

def remove_dir (path): dirList, flsList = xbmcvfs.listdir(path)
       for fl in flsList: xbmcvfs.delete(os.path.join(path, fl))
       for dr in dirList: remove_dir(os.path.join(path, dr))
       xbmcvfs.rmdir(path)

remove_dir(xbmc.translatePath('special://home/addons/changeme'))
remove_dir(xbmc.translatePath('special://home/addons/plugin.program.indigo'))
remove_dir(xbmc.translatePath('special://home/userdata/plugin.program.indigo'))
remove_dir(xbmc.translatePath('special://home/userdata/addon_data/changeme'))

dialog = xbmcgui.Dialog()
dialog.ok("[COLOR orange]TechNEWSology[/COLOR]", "Bye Bye --> plugin.program.indigo")