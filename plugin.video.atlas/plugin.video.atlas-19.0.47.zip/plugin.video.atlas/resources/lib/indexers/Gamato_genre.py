import xbmc, xbmcgui


def gamato_genre():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17, click_18, click_19, click_20, click_21)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                            Κατηγορίες [/COLOR][/B]', 
['[B][COLOR=white]                                                       Western[/COLOR][/B]',
 '[B][COLOR=white]                                                    Αστυνομική[/COLOR][/B]',
 '[B][COLOR=white]                                                         Δράμα[/COLOR][/B]',
 '[B][COLOR=white]                                                         Δράση[/COLOR][/B]',
 '[B][COLOR=white]                                                 Επ. Φαντασίας[/COLOR][/B]',
 '[B][COLOR=white]                                                        Θρίλερ[/COLOR][/B]',
 '[B][COLOR=white]                                                      Ιστορική[/COLOR][/B]',
 '[B][COLOR=white]                                              Κινούμενα σχέδια[/COLOR][/B]',
 '[B][COLOR=white]                                                       Κωμωδία[/COLOR][/B]',
 '[B][COLOR=white]                                                Μεταγλωτισμένα[/COLOR][/B]',
 '[B][COLOR=white]                                                       Μουσική[/COLOR][/B]',
 '[B][COLOR=white]                                                     Μυστηρίου[/COLOR][/B]',
 '[B][COLOR=white]                                                   Ντοκιμαντέρ[/COLOR][/B]',
 '[B][COLOR=white]                                                  Οικογενειακή[/COLOR][/B]',
 '[B][COLOR=white]                                                    Περιπέτεια[/COLOR][/B]',
 '[B][COLOR=white]                                                      Πολεμική[/COLOR][/B]',
 '[B][COLOR=white]                                                     Ρομαντική[/COLOR][/B]',
 '[B][COLOR=white]                                                        Τρόμου[/COLOR][/B]',
 '[B][COLOR=white]                                                     Φαντασίας[/COLOR][/B]',
 '[B][COLOR=white]                                                     Film-Noir[/COLOR][/B]',
 '[B][COLOR=white]                                            Χριστουγεννιάτικες[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-21]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/western/ )')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%b1%cf%83%cf%84%cf%85%ce%bd%ce%bf%ce%bc%ce%b9%ce%ba%ce%ae/ )')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%b4%cf%81%ce%ac%ce%bc%ce%b1/ )')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%b4%cf%81%ce%ac%cf%83%ce%b7/ )')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%b5%cf%80-%cf%86%ce%b1%ce%bd%cf%84%ce%b1%cf%83%ce%af%ce%b1%cf%82/ )')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%b8%cf%81%ce%af%ce%bb%ce%b5%cf%81/ )')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%b9%cf%83%cf%84%ce%bf%cf%81%ce%b9%ce%ba%ce%ae/ )')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%ba%ce%b9%ce%bd%ce%bf%cf%8d%ce%bc%ce%b5%ce%bd%ce%b1-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/ )')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%ba%cf%89%ce%bc%cf%89%ce%b4%ce%af%ce%b1/ )')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre//gamato/ )')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%bc%ce%bf%cf%85%cf%83%ce%b9%ce%ba%ce%ae/ )')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%bc%cf%85%cf%83%cf%84%ce%b7%cf%81%ce%af%ce%bf%cf%85/ )')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%bd%cf%84%ce%bf%ce%ba%cf%85%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/ )')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%ce%bf%ce%b9%ce%ba%ce%bf%ce%b3%ce%b5%ce%bd%ce%b5%ce%b9%ce%b1%ce%ba%ce%ae/ )')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%cf%80%ce%b5%cf%81%ce%b9%cf%80%ce%ad%cf%84%ce%b5%ce%b9%ce%b1/ )')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%cf%80%ce%bf%ce%bb%ce%b5%ce%bc%ce%b9%ce%ba%ce%ae/ )')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%cf%81%ce%bf%ce%bc%ce%b1%ce%bd%cf%84%ce%b9%ce%ba%ce%ae/ )')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%cf%84%cf%81%cf%8c%ce%bc%ce%bf%cf%85/ )')

def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/%cf%86%ce%b1%ce%bd%cf%84%ce%b1%cf%83%ce%af%ce%b1%cf%82/ )')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/film-noir/ )')

def click_21():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=4&amp;url=http://gamatotv.info/genre/christmas/ )')