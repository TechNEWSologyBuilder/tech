# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_GAMATOMOVIES = ART + 'gamatomovies.png'
GAMATOMOVIES = control.setting('gamatomovies') or 'https://gamatomovies.gr/'


def menu_year(): #124
    addDir('[COLOR white]2022[/COLOR]', GAMATOMOVIES + 'years/2022', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2021[/COLOR]', GAMATOMOVIES + 'years/2021', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2020[/COLOR]', GAMATOMOVIES + 'years/2020', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2019[/COLOR]', GAMATOMOVIES + 'years/2019', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2018[/COLOR]', GAMATOMOVIES + 'years/2018', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2017[/COLOR]', GAMATOMOVIES + 'years/2017', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2016[/COLOR]', GAMATOMOVIES + 'years/2016', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2015[/COLOR]', GAMATOMOVIES + 'years/2015', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2014[/COLOR]', GAMATOMOVIES + 'years/2014', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2013[/COLOR]', GAMATOMOVIES + 'years/2013', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2012[/COLOR]', GAMATOMOVIES + 'years/2012', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2011[/COLOR]', GAMATOMOVIES + 'years/2011', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2010[/COLOR]', GAMATOMOVIES + 'years/2010', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2009[/COLOR]', GAMATOMOVIES + 'years/2009', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2008[/COLOR]', GAMATOMOVIES + 'years/2008', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2007[/COLOR]', GAMATOMOVIES + 'years/2007', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2006[/COLOR]', GAMATOMOVIES + 'years/2006', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2005[/COLOR]', GAMATOMOVIES + 'years/2005', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2004[/COLOR]', GAMATOMOVIES + 'years/2004', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2003[/COLOR]', GAMATOMOVIES + 'years/2003', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2002[/COLOR]', GAMATOMOVIES + 'years/2002', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2001[/COLOR]', GAMATOMOVIES + 'years/2001', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]2000[/COLOR]', GAMATOMOVIES + 'years/2000', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1999[/COLOR]', GAMATOMOVIES + 'years/1999', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1998[/COLOR]', GAMATOMOVIES + 'years/1998', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1997[/COLOR]', GAMATOMOVIES + 'years/1997', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1996[/COLOR]', GAMATOMOVIES + 'years/1996', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1995[/COLOR]', GAMATOMOVIES + 'years/1995', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1994[/COLOR]', GAMATOMOVIES + 'years/1994', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1993[/COLOR]', GAMATOMOVIES + 'years/1993', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1992[/COLOR]', GAMATOMOVIES + 'years/1992', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1991[/COLOR]', GAMATOMOVIES + 'years/1991', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1990[/COLOR]', GAMATOMOVIES + 'years/1990', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1989[/COLOR]', GAMATOMOVIES + 'years/1989', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1988[/COLOR]', GAMATOMOVIES + 'years/1988', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1987[/COLOR]', GAMATOMOVIES + 'years/1987', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1986[/COLOR]', GAMATOMOVIES + 'years/1986', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1985[/COLOR]', GAMATOMOVIES + 'years/1985', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1984[/COLOR]', GAMATOMOVIES + 'years/1984', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1983[/COLOR]', GAMATOMOVIES + 'years/1983', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1982[/COLOR]', GAMATOMOVIES + 'years/1982', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1981[/COLOR]', GAMATOMOVIES + 'years/1981', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1980[/COLOR]', GAMATOMOVIES + 'years/1980', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1979[/COLOR]', GAMATOMOVIES + 'years/1979', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1978[/COLOR]', GAMATOMOVIES + 'years/1978', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1977[/COLOR]', GAMATOMOVIES + 'years/1977', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1976[/COLOR]', GAMATOMOVIES + 'years/1976', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1975[/COLOR]', GAMATOMOVIES + 'years/1975', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1974[/COLOR]', GAMATOMOVIES + 'years/1974', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1973[/COLOR]', GAMATOMOVIES + 'years/1973', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1972[/COLOR]', GAMATOMOVIES + 'years/1972', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1971[/COLOR]', GAMATOMOVIES + 'years/1971', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1970[/COLOR]', GAMATOMOVIES + 'years/1970', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1969[/COLOR]', GAMATOMOVIES + 'years/1969', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1968[/COLOR]', GAMATOMOVIES + 'years/1968', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1967[/COLOR]', GAMATOMOVIES + 'years/1967', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1966[/COLOR]', GAMATOMOVIES + 'years/1966', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1965[/COLOR]', GAMATOMOVIES + 'years/1965', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1964[/COLOR]', GAMATOMOVIES + 'years/1964', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1963[/COLOR]', GAMATOMOVIES + 'years/1963', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]1962[/COLOR]', GAMATOMOVIES + 'years/1962', 122, icon_GAMATOMOVIES, FANART, '')


def menu_genre(): #125
    addDir('[COLOR white]Αστυνομική[/COLOR]', GAMATOMOVIES + 'tainies/crime/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Βιογραφία[/COLOR]', GAMATOMOVIES + 'tainies/biography/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Δράμα[/COLOR]', GAMATOMOVIES + 'tainies/drama/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Επ. Φαντασίας[/COLOR]', GAMATOMOVIES + 'tainies/sci-fi/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Θρίλερ[/COLOR]', GAMATOMOVIES + 'tainies/thriller/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Ιστορική[/COLOR]', GAMATOMOVIES + 'tainies/history/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Κινούμενα Σχέδια[/COLOR]', GAMATOMOVIES + 'tainies/animation/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Κωμωδία[/COLOR]', GAMATOMOVIES + 'tainies/comedy/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Μουσική[/COLOR]', GAMATOMOVIES + 'tainies/music/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Μυστηρίου[/COLOR]', GAMATOMOVIES + 'tainies/mystery/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Ντοκιμαντέρ[/COLOR]', GAMATOMOVIES + 'tainies/documentary/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Οικογενειακή[/COLOR]', GAMATOMOVIES + 'tainies/family/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Περιπέτεια[/COLOR]', GAMATOMOVIES + 'tainies/adventure/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Πολεμική[/COLOR]', GAMATOMOVIES + 'tainies/war/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Ρομαντική[/COLOR]', GAMATOMOVIES + 'tainies/romance/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Τρόμου[/COLOR]', GAMATOMOVIES + 'tainies/horror/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Φαντασίας[/COLOR]', GAMATOMOVIES + 'tainies/fantasy/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Western[/COLOR]', GAMATOMOVIES + 'tainies/western/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Bollywood[/COLOR]', GAMATOMOVIES + 'tainies/bollywood/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Ελληνική Ταινία[/COLOR]', GAMATOMOVIES + 'tainies/elliniki-tainia/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Πασχαλινή[/COLOR]', GAMATOMOVIES + 'tainies/easter/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Χριστουγεννιάτικη[/COLOR]', GAMATOMOVIES + 'tainies/χριστουγεννιάτικη/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[COLOR white]Αγίου Βαλεντίνου[/COLOR]', GAMATOMOVIES + 'tainies/valentinesday/', 122, icon_GAMATOMOVIES, FANART, '')


def gamatomovies(url): #122
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="gp-image-align-left">\s*<a href="(.+?)" title="(.+?)">\s*<img src="(.+?)"', re.DOTALL).findall(p)
    for url, name, icon in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 123, icon , FANART, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 122, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #123
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<a href="(.+?)" target="_blank" rel="nofollow noopener noreferrer">(.+?)</a></td>').findall(p)
        t = re.compile('<div class="gp-entry-title">(.+?)</div>').findall(p)
    #    link_list = ['HDVID', 'STREAMTAPE']
        link_list_Out = ['NETU', 'ΕΛΛΗΝΙΚΟΙ ΕΞΩΤΕΡΙΚΟΙ']
        for url, link in m:
            for name in t:
        #        if any(x in link for x in link_list):
                if not any(x in link for x in link_list_Out):
                    link = ' | ' + link
                    name = clear_Title(name)
                    url = url.replace('http', 'https').replace('httpss', 'https')
                    addDir((name+link), url, 100, iconimage, FANART, str(description))


def gamatomoviestv(url): #126
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="gp-image-align-left">\s*<a href="(.+?)" title="(.+?)">\s*<img src="(.+?)"', re.DOTALL).findall(p)
    for url, name, icon in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 127, icon , FANART, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 126, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass

def season_tv(url): #127
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, '')
    else:
        m = re.compile('<a class=".+?" href="(.+?)" title="" target="_blank">(.+?)</a>', re.DOTALL).findall(p)
        img = re.compile('<meta property="og:image" content="(.+?)" />\s<meta property="og:image:width" content=".+?" />', re.DOTALL).findall(p)
        for url, season in m:
            for icon in img:
                addDir('[B][COLOR white]%s[/COLOR][/B]' % season, url, 129, icon , FANART, '')


def epi_tv(url): #129
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a class="col-sm-3" href="(.+?)">\s*<img class="media-object img-responsive" src="(.+?)" alt="(.+?)">').findall(p)
    for url, icon, epi in m:
    #    if not 'Επεισόδιο' in epi:
    #        epi = 'Επεισόδιο ' + epi
    #        addDir(epi, url, 130, icon, FANART, '')
    #    else:
        addDir(epi, url, 130, icon, FANART, '')


def get_links_tv(name, url, iconimage, description): #130
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('{"id":.+?,"url":"(.+?)".+?;').findall(p)
    t = re.compile('<title>(.+?)</title>').findall(p)
    for url in m:
        for name in t:
            name = name.replace(' Greek subs ταινίες online | gamato-movies.com', '').replace(',', '').replace('Season ', 'S0').replace('Επεισόδιο ', 'E0')
            url = url.replace('http', 'https').replace('httpss', 'https').replace('\/', '/')
            addDir(name, url, 100, iconimage, FANART, str(description))


def search(url): #121
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://gamatomovies.gr/?s=' + search
        gamatomovies(url)

def search_tv(url): #131
    keyb = xbmc.Keyboard('', 'Αναζήτηση Τήλ.Σειράς...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://gamatomovies.gr/?s=' + search
        gamatomoviestv(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
