# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_fmovies = ART + 'fmovies.png'
FMOVIES = 'https://fmovies.vision'


def menu_year(): #135
    addDir('[COLOR white]2022[/COLOR]', FMOVIES + '/xfsearch/release-date/2022/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2021[/COLOR]', FMOVIES + '/xfsearch/release-date/2021/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2020[/COLOR]', FMOVIES + '/xfsearch/release-date/2020/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2019[/COLOR]', FMOVIES + '/xfsearch/release-date/2019/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2018[/COLOR]', FMOVIES + '/xfsearch/release-date/2018/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2017[/COLOR]', FMOVIES + '/xfsearch/release-date/2017/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2016[/COLOR]', FMOVIES + '/xfsearch/release-date/2016/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2015[/COLOR]', FMOVIES + '/xfsearch/release-date/2015/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2014[/COLOR]', FMOVIES + '/xfsearch/release-date/2014/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2013[/COLOR]', FMOVIES + '/xfsearch/release-date/2013/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2012[/COLOR]', FMOVIES + '/xfsearch/release-date/2012/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2011[/COLOR]', FMOVIES + '/xfsearch/release-date/2011/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2010[/COLOR]', FMOVIES + '/xfsearch/release-date/2010/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2009[/COLOR]', FMOVIES + '/xfsearch/release-date/2009/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2008[/COLOR]', FMOVIES + '/xfsearch/release-date/2008/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2007[/COLOR]', FMOVIES + '/xfsearch/release-date/2007/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2006[/COLOR]', FMOVIES + '/xfsearch/release-date/2006/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2005[/COLOR]', FMOVIES + '/xfsearch/release-date/2005/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2004[/COLOR]', FMOVIES + '/xfsearch/release-date/2004/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2003[/COLOR]', FMOVIES + '/xfsearch/release-date/2003/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2002[/COLOR]', FMOVIES + '/xfsearch/release-date/2002/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2001[/COLOR]', FMOVIES + '/xfsearch/release-date/2001/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]2000[/COLOR]', FMOVIES + '/xfsearch/release-date/2000/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1999[/COLOR]', FMOVIES + '/xfsearch/release-date/1999/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1998[/COLOR]', FMOVIES + '/xfsearch/release-date/1998/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1997[/COLOR]', FMOVIES + '/xfsearch/release-date/1997/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1996[/COLOR]', FMOVIES + '/xfsearch/release-date/1996/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1995[/COLOR]', FMOVIES + '/xfsearch/release-date/1995/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1994[/COLOR]', FMOVIES + '/xfsearch/release-date/1994/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1993[/COLOR]', FMOVIES + '/xfsearch/release-date/1993/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1992[/COLOR]', FMOVIES + '/xfsearch/release-date/1992/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1991[/COLOR]', FMOVIES + '/xfsearch/release-date/1991/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]1990[/COLOR]', FMOVIES + '/xfsearch/release-date/1990/', 139, icon_fmovies, FANART, '')


def menu_genre(): #136
    addDir('[COLOR white]Action[/COLOR]', FMOVIES + '/action/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Adventure[/COLOR]', FMOVIES + '/adventure/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Animation[/COLOR]', FMOVIES + '/animation/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Comedy[/COLOR]', FMOVIES + '/comedy/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Crime[/COLOR]', FMOVIES + '/crime/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Documentary[/COLOR]', FMOVIES + '/documentary/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Drama[/COLOR]', FMOVIES + '/drama/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Family[/COLOR]', FMOVIES + '/family/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Fantasy[/COLOR]', FMOVIES + '/fantasy/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]History[/COLOR]', FMOVIES + '/history/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Horror[/COLOR]', FMOVIES + '/horror/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Music[/COLOR]', FMOVIES + '/music/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Mystery[/COLOR]', FMOVIES + '/mystery/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Romance[/COLOR]', FMOVIES + '/romance/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Science-Fiction[/COLOR]', FMOVIES + '/science-fiction/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Thriller[/COLOR]', FMOVIES + '/thriller/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Tv Movie[/COLOR]', FMOVIES + '/tv-war/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]War[/COLOR]', FMOVIES + '/war/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Western[/COLOR]', FMOVIES + '/western/', 139, icon_fmovies, FANART, '')
    addDir('[COLOR white]Cinema[/COLOR]', FMOVIES + '/cinema/', 139, icon_fmovies, FANART, '')


def fmovies(url): #139
    hdrs = {'Referer': FMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="quality">(.+?)</div>\s+</div> <a href="(.+?)" title="(.+?)" class="poster"> <img class="lazyload" data-src="(.+?)".+?<div class="meta">(.+?) <i class="dot"></i> (.+?) <', re.DOTALL).findall(p)
    for info, url, name, icon, years, time in m:
        name = clear_Title(name)
        icon = FMOVIES + icon
        years = '[B][COLOR white] (%s)[/COLOR][/B]' % years
        time = time.replace('min','λεπτά')
        time = ' | ' + '[B][COLOR blue]%s[/COLOR][/B]' % time
        info = ' | ' + '[B][COLOR lime]%s[/COLOR][/B]' % info
        addDir(('[B][COLOR white]%s[/COLOR][/B]' % name + years + info + time), url, 137, icon , FANART, '')
    try:
        m = re.compile('<a href="(.+?)">»</a>').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 139, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #137
    hdrs = {'Referer': FMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<div data-toggle="modal" data-target="#md-trailer" data-trailer="(.+?)">').findall(p)
    s = re.compile('<title>(.+?)</title>').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<script src="(.+?)"></script>\s+</div>').findall(p)
        for url in m:
            for name in s:
                name = name.replace('Watch ','').replace(' Online Free | FMovies','')
                name = clear_Title(name)
                addDir(name, url, 138, iconimage, FANART, str(description))


def get_links_s(name, url, iconimage, description): #138
    hdrs = {'Referer': FMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    p = p.replace("\\", "")
    m = re.compile('''<tr onclick="window\.open\( \\'(.+?)\\' \)">''').findall(p)
    for url in m:
        if 'supervideo' in url:
            link = ' | Supervideo'
            addDir((name + link), url, 100, iconimage, FANART, str(description))
        elif 'mixdrop' in url:
            link = ' | Mixdrop'
            addDir((name + link), url, 100, iconimage, FANART, str(description))
        elif 'streamtape' in url:
            link = ' | Streamtape'
            addDir((name + link), url, 100, iconimage, FANART, str(description))
        elif 'dropload' in url:
            link = ' | Dropload'
            addDir((name + link), url, 100, iconimage, FANART, str(description))
        elif 'voe' in url:
            link = ' | Voe'
            addDir((name + link), url, 100, iconimage, FANART, str(description))
        else:
            link = ' | link'
            addDir((name + link), url, 100, iconimage, FANART, str(description))

def search(url): #134
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = '' + search
        fmovies(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
