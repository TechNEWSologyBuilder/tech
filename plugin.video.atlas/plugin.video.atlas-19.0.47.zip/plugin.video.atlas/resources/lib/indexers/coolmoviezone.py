# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
coolmoviezone_icon = ART + 'coolmoviezone.png'

COOLMOVIEZONE = control.setting('coolmoviezone') or 'https://coolmoviezone.news/'



def menu_year(): #
    addDir('[COLOR white]2021[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2021', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2020[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2020', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2019[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2019', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2018[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2018', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2017[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2017', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2016[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2016', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2015[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2015', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2014[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2014', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2013[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2013', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2012[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2012', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2011[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2011', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2010[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2010', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2009[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2009', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2008[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2008', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2007[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2007', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2006[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2006', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2005[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2005', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2004[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2004', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2003[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2003', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2002[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2002', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2001[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2001', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]2000[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-2000', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1999[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1999', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1998[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1998', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1997[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1997', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1996[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1996', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1995[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1995', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1994[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1994', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1993[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1993', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1992[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1992', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1991[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1991', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1990[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1990', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1989[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1989', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1988[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1988', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1987[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1987', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]1986[/COLOR]', 'https://coolmoviezone.news/tag/browse-year-1986', 114, coolmoviezone_icon, FANART, '')


def menu_genre(): #
    addDir('[COLOR white]+18[/COLOR]', COOLMOVIEZONE + 'category/18movies/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Action[/COLOR]', COOLMOVIEZONE + 'category/action/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Adventure[/COLOR]', COOLMOVIEZONE + 'category/adventure/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Animation[/COLOR]', COOLMOVIEZONE + 'category/animation/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Bengali[/COLOR]', COOLMOVIEZONE + 'category/bengali-movie/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Biography[/COLOR]', COOLMOVIEZONE + 'category/biography/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Comedy[/COLOR]', COOLMOVIEZONE + 'category/comedy/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Crime[/COLOR]', COOLMOVIEZONE + 'category/crime/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Documentary[/COLOR]', COOLMOVIEZONE + 'category/documentary/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Drama[/COLOR]', COOLMOVIEZONE + 'category/drama/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Family[/COLOR]', COOLMOVIEZONE + 'category/family/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Fantasy[/COLOR]', COOLMOVIEZONE + 'category/fantasy/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Featured[/COLOR]', COOLMOVIEZONE + 'category/featured/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Hindi Dubbed[/COLOR]', COOLMOVIEZONE + 'category/hindi-dubbed/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Horror[/COLOR]', COOLMOVIEZONE + 'category/horror/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Latest[/COLOR]', COOLMOVIEZONE + 'category/latest/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Malayalam[/COLOR]', COOLMOVIEZONE + 'category/malayalam-movies/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Marathi[/COLOR]', COOLMOVIEZONE + 'category/marathi_movies/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Music[/COLOR]', COOLMOVIEZONE + 'category/music/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Musical[/COLOR]', COOLMOVIEZONE + 'category/musical/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Mystery[/COLOR]', COOLMOVIEZONE + 'category/mystery/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]New Bollywood Movies[/COLOR]', COOLMOVIEZONE + 'category/watch-new-bollywood-movies/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Other[/COLOR]', COOLMOVIEZONE + 'category/other-movie/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Punjabi Movies[/COLOR]', COOLMOVIEZONE + 'category/punjabi_movies/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Reality Tv[/COLOR]', COOLMOVIEZONE + 'category/reality-tv/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Romance[/COLOR]', COOLMOVIEZONE + 'category/romance/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Sci-Fi[/COLOR]', COOLMOVIEZONE + 'category/sci-fi/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Short[/COLOR]', COOLMOVIEZONE + 'category/short/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Sport[/COLOR]', COOLMOVIEZONE + 'category/sport/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Tamil[/COLOR]', COOLMOVIEZONE + 'category/tamil-movie/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Telugu[/COLOR]', COOLMOVIEZONE + 'category/telugu-movie/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Thriller[/COLOR]', COOLMOVIEZONE + 'category/thriller/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Trailer And Review[/COLOR]', COOLMOVIEZONE + 'category/trailer-and-review/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Tv Series[/COLOR]', COOLMOVIEZONE + 'category/tv-series/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Upcoming[/COLOR]', COOLMOVIEZONE + 'category/upcoming/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]War[/COLOR]', COOLMOVIEZONE + 'category/war/', 114, coolmoviezone_icon, FANART, '')
    addDir('[COLOR white]Western[/COLOR]', COOLMOVIEZONE + 'category/western/', 114, coolmoviezone_icon, FANART, '')


def coolmoviezone(url): #109
    hdrs = {'Referer': COOLMOVIEZONE,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<li>\s<a href="(.+?)" class="thumbnail-wrapper"><img src="(.+?)".+?rel="bookmark">(.+?)\s</a></span>', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 110, icon , FANART, '')
    try:
        m = re.compile('<a class="nextpostslink" rel="next" aria-label="Next Page" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 109, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def coolmoviezone_search(url): #116
    hdrs = {'Referer': COOLMOVIEZONE,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<h1><a href="(.+?)" rel="bookmark">(.+?)</a></h1>', re.DOTALL).findall(p)
    for url, name in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 115, '' , FANART, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 116, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def coolmoviezone_2(url): #114
    hdrs = {'Referer': COOLMOVIEZONE,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<h1><a href="(.+?)" rel="bookmark">(.+?)</a></h1>.+? src="(.+?)"', re.DOTALL).findall(p)
    for url, name, icon in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 115, icon , FANART, '')
    try:
        m = re.compile('<a class="nextpostslink" rel="next" aria-label="Next Page" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 114, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #110
    hdrs = {'Referer': COOLMOVIEZONE,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<td align="center"><strong><a href="(.+?)">(.+?)</a></strong></td>', re.DOTALL).findall(p)
    t = re.compile('<meta property="og:title" content="(.+?)" />').findall(p)
    for url, link in m:
        for name in t:
            name = name.replace(' Full Movie Online Free on CoolMovieZone', '').replace('Watch ', '')
            name = clear_Title(name)
            link = link.replace('Watch Version', 'Link')
            link = ' | ' + link
            addDir((name+link), url, 100, iconimage, FANART, str(description))

def get_links_search(name, url, iconimage, description): #115
    hdrs = {'Referer': COOLMOVIEZONE,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<td align="center"><strong><a href="(.+?)">(.+?)</a></strong></td>').findall(p)
    t = re.compile('<meta property="og:title" content="(.+?)" />').findall(p)
    for url, link in m:
        for name in t:
            name = name.replace(' Full Movie Online Free on CoolMovieZone', '').replace('Watch ', '')
            name = clear_Title(name)
            link = link.replace('Watch Version', 'Link')
            link = ' | ' + link
            addDir((name+link), url, 100, iconimage, FANART, str(description))


def search(url): #113
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://coolmoviezone.news/index.php?s=' + search
        coolmoviezone_2(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
